#ifndef TURENT_HH
#define TURENT_HH

#include <ClanLib/core.h>

class Tank;

class Turent
{
private:
  Tank* tank;

  CL_Surface sur;

  // The angle of the turent relative to the tank in radians
  float angle;

public:
  Turent (Tank*);
  ~Turent ();

  void draw ();
  void update ();

  void increase_angle ();
  void decrease_angle ();
  void set_angle (float angle);
};

#endif // TURENT_HH

// EOF
